
from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from database import SessionLocal, engine
from models import Base
from schemas import EmployeeSentimentScoreSchema
from crud import get_sentiments

app = FastAPI()

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/sentiments", response_model=list[EmployeeSentimentScoreSchema])
def read_sentiments(db: Session = Depends(get_db)):
    return get_sentiments(db)

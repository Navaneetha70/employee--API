
from sqlalchemy import Column, Integer, Float, Text, DateTime, ForeignKey
from sqlalchemy.dialects.sqlite import BLOB
from database import Base
import uuid
from datetime import datetime

class EmployeeSentimentScore(Base):
    __tablename__ = 'employee_sentiment_scores'

    id = Column(Text, primary_key=True, default=lambda: str(uuid.uuid4()))
    employeeId = Column(Text)
    totalMentions = Column(Integer)
    emailCountAnalyzed = Column(Integer)
    positiveMentions = Column(Integer)
    neutralMentions = Column(Integer)
    negativeMentions = Column(Integer)
    managementComplaints = Column(Integer)
    payComplaints = Column(Integer)
    harassmentConcerns = Column(Integer)
    positiveScore = Column(Float)
    negativeScore = Column(Float)
    overallSentimentScore = Column(Float)
    trendScore = Column(Float)
    analysisDate = Column(DateTime)
    createdAt = Column(DateTime, default=datetime.utcnow)
    updatedAt = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    remark = Column(Text)
